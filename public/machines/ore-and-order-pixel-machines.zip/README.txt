ORE & ORDER — SEMI-PIXEL MACHINE ART PACK

Contains ten matching machines:
miner, smelter, press, assembler, copperMiner, copperSmelter, wiremill, circuitpress, beamMill, coilWinder.

icons/ - 100x100 and 200x200 pixel-art icons with crisp nearest-neighbour scaling.
animated_gifs/ - looping GIF previews of each animated industrial machine.
game_sprite_sheets/ - seven-frame horizontal strips, 700x100 pixels.

In Ore & Order the live game builds its own pixel-art sheets from the existing machine WebP assets, so you DO NOT have to upload these files to see the new visual style.

For a new project: load a game_sprite_sheets PNG/WebP as background, use background-size: 700% 100%, and animate background-position from 0% to 100% using steps(6,end), with duration equal to the machine's production cycle. Pause animation when the machine has no inputs/is broken. Use image-rendering: pixelated.

The GIFs are standalone animated preview assets and do not synchronise with the game clock.
