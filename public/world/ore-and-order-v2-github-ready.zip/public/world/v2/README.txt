ORE & ORDER STARTING AREA ASSETS

Use terrain/*.png as 32x32 opaque repeating tiles.
Use sprites/*.png as alpha sprites with bottom-center anchors. Preserve aspect ratio; do not force 32x32 sizing for buildings.
Use variants/*_off.png until power is restored.
For interior: hide the factory exterior roof-bearing sprite and show buildings/factory_interior_roofless.png; the original roof cannot be physically removed from the baked exterior without redraw.
Use buildings/mine_plot_empty.png initially; overlay mine_blueprint_overlay.png only while selecting construction. No mine should exist at first launch.
The pixel-art sprite cutouts were automatically segmented from an AI-generated sheet. Some edges and occluded areas may require hand cleanup. The roofless interior is a new drawn replacement, not a perfect match to the exterior.
